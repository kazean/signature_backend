package com.example.memorydb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MemorydbApplication {

	public static void main(String[] args) {
		SpringApplication.run(MemorydbApplication.class, args);
	}

}
